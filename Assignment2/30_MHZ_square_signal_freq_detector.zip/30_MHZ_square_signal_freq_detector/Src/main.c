
#include "stm32f4xx_hal.h"
#include "main.h"
#include "string.h"
#include "stdio.h"




void Error_handler(void);
void GPIO_Init(void);
void SystemClock_Config(uint8_t );
void TIM2_Init(void);
void LSE_configuration(void);
void UART2_Init(void);

TIM_HandleTypeDef htimer2;
UART_HandleTypeDef Uart2;


uint32_t input_capture[2] = {0}; //to capture two consecutive edges
char ten_sec_data[50]; //for print 10 seconds pulse count
uint8_t count=1; // count for edges capturing
uint32_t pulse_count = 0; //to count pulse for 10 seconds
uint32_t pulse_count_10_sec = 0; //pulse count in 10 seconds
uint8_t check_not_10sec = TRUE;  //flag for 10 seconds
volatile uint8_t  is_capture_done = FALSE;//flag for frequency calculation

int main(void){
	uint32_t capture;
	double timer_Frequency = 0;
	double reference_Period = 0;
	double Period = 0;
	double Out_Ferquency = 0;
	char Frequecy_values[100];
	char pulse[100];
	HAL_Init();

	SystemClock_Config(SYS_CLOCK_FREQ_100_MHZ); //50mhz clock setting

	UART2_Init();


	GPIO_Init();

	TIM2_Init();

	LSE_configuration();


	HAL_TIM_IC_Start_IT(&htimer2,TIM_CHANNEL_1);

	sprintf(Frequecy_values, "Frequency of the signal applied = %f\r\n",Out_Ferquency);
	HAL_UART_Transmit(&Uart2,(uint8_t *)Frequecy_values,strlen(Frequecy_values),HAL_MAX_DELAY);


	while(1){

	if(is_capture_done)  {
		if(input_capture[1] > input_capture[0] )
		{
			capture = input_capture[1] - input_capture[0];
		}
		else{
			capture = (0xffffffff - input_capture[0]) + input_capture[1];
		}

		timer_Frequency = ( HAL_RCC_GetPCLK1Freq() * 2 )/(htimer2.Init.Prescaler +1);
		reference_Period = 1/timer_Frequency;

		Period = capture * reference_Period;

		Out_Ferquency = 1/Period ;
		//checking frequency for 30 MHZ
		if( Out_Ferquency == 3000000)
		{
			sprintf(Frequecy_values, "30MHZ signal detected\r\n");
		}
		else{
			sprintf(Frequecy_values, " ");
		}
		HAL_UART_Transmit(&Uart2,(uint8_t *)Frequecy_values,strlen(Frequecy_values),HAL_MAX_DELAY);

		//printing frequency
		sprintf(Frequecy_values, "Frequency of the signal applied = %f\r\n",Out_Ferquency);
		HAL_UART_Transmit(&Uart2,(uint8_t *)Frequecy_values,strlen(Frequecy_values),HAL_MAX_DELAY);

		//printing pulse count
		sprintf(pulse, "number of pulses = %d\r\n",pulse_count);
		HAL_UART_Transmit(&Uart2,(uint8_t *)pulse,strlen(pulse),HAL_MAX_DELAY);

		is_capture_done = FALSE;
		}
		if(check_not_10sec== FALSE)
		{

			break;
		}
	}
	return 0;
}

void SystemClock_Config(uint8_t clock_freq){

	RCC_OscInitTypeDef osc_init;
	RCC_ClkInitTypeDef clk_init;
	uint32_t FLatency;

	//turning on both HSI and LSE clock using bitwise OR between macros
	osc_init.OscillatorType = RCC_OSCILLATORTYPE_HSI | RCC_OSCILLATORTYPE_LSE;
	osc_init.HSIState = RCC_HSI_ON;
	osc_init.LSEState = RCC_LSE_ON;
	osc_init.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT; //16
	osc_init.PLL.PLLState = RCC_PLL_ON;
	osc_init.PLL.PLLSource = RCC_PLLSOURCE_HSI;

	switch(clock_freq){

	case SYS_CLOCK_FREQ_100_MHZ:
	{
		osc_init.PLL.PLLM = 16;
		osc_init.PLL.PLLN = 200;
		osc_init.PLL.PLLP = 2;
		osc_init.PLL.PLLQ = 2;
		clk_init.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | \
							    					RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;

		clk_init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
		clk_init.AHBCLKDivider = RCC_SYSCLK_DIV1;
		clk_init.APB1CLKDivider = RCC_HCLK_DIV4;
		clk_init.APB2CLKDivider = RCC_HCLK_DIV2;

		FLatency = FLASH_ACR_LATENCY_4WS;
		break;
	}
	case SYS_CLOCK_FREQ_120_MHZ:
		{
			osc_init.PLL.PLLM = 16;
			osc_init.PLL.PLLN = 240;
			osc_init.PLL.PLLP = 2;
			osc_init.PLL.PLLQ = 2;
			clk_init.ClockType = RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | \
								    					RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;

			clk_init.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
			clk_init.AHBCLKDivider = RCC_SYSCLK_DIV1;
			clk_init.APB1CLKDivider = RCC_HCLK_DIV4;
			clk_init.APB2CLKDivider = RCC_HCLK_DIV2;

			FLatency = FLASH_ACR_LATENCY_4WS;
			break;
		}
	default:
		return;

	}


	if( HAL_RCC_OscConfig(&osc_init) != HAL_OK){
			//Error_Handler();
		}

	if( HAL_RCC_ClockConfig(&clk_init ,FLatency ) != HAL_OK){
				//Error_Handler();
   }

	// Systick Configuration

	HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

	HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

}

void UART2_Init(void){
	Uart2.Instance = USART2;
	Uart2.Init.BaudRate = 115200;
	Uart2.Init.WordLength = UART_WORDLENGTH_8B;
	Uart2.Init.StopBits=   UART_STOPBITS_1;
	Uart2.Init.Parity = UART_PARITY_NONE;
	Uart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	Uart2.Init.Mode = UART_MODE_TX_RX;
	HAL_StatusTypeDef status = HAL_UART_Init(&Uart2);
	if(status != HAL_OK ){
		// if initialization not happened correctly
		Error_handler();
	}

}

void GPIO_Init(void){

	__HAL_RCC_GPIOA_CLK_ENABLE();

	GPIO_InitTypeDef led_gpio;
	led_gpio.Pin = GPIO_PIN_5;
	led_gpio.Mode = GPIO_MODE_OUTPUT_PP;
	HAL_GPIO_Init(GPIOA,&led_gpio);
}


//call back function
void TIM2_Init(void){
	TIM_IC_InitTypeDef timer2IC_Config;
	htimer2.Instance = TIM2;
	htimer2.Init.CounterMode = TIM_COUNTERMODE_UP;
	htimer2.Init.Period = 0xffffffff;
	htimer2.Init.Prescaler = 1;
	if( HAL_TIM_IC_Init(&htimer2) != HAL_OK){
		Error_handler();
	}
	timer2IC_Config.ICFilter = 0;
	timer2IC_Config.ICPolarity = TIM_ICPOLARITY_RISING;
	timer2IC_Config.ICPrescaler = TIM_ICPSC_DIV1;
	timer2IC_Config.ICSelection = TIM_ICSELECTION_DIRECTTI;

	if( HAL_TIM_IC_ConfigChannel(&htimer2,&timer2IC_Config,TIM_CHANNEL_1) != HAL_OK){
		Error_handler();
	}


}
void LSE_configuration(void){
	// outputting LSE clock through PA8 pin
	// Here we turning ON LSE clock
	// but we already did in systemclockconfig() function so here commented
#if 0
	RCC_OscInitTypeDef osc_init;

	osc_init.OscillatorType  = RCC_OSCILLATORTYPE_LSE;
	osc_init.LSEState = RCC_LSE_ON;
	//enabling LSE
	if( HAL_RCC_OscConfig(&osc_init) != HAL_OK){
			while(1);
			// do something like turn on LEDs/
		}
#endif

	//OUTPUTTING through PA8 MC01
	HAL_RCC_MCOConfig(RCC_MCO1,RCC_MCO1SOURCE_LSE,RCC_MCODIV_1);

}

// positive edge is found

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim)
{
	//capuring two consecutive pulses
	if(! is_capture_done){

		if(count == 1){
	  input_capture[0] = __HAL_TIM_GET_COMPARE(htim,TIM_CHANNEL_1);
	  count = 2;
  }

  else if(count == 2){
	  input_capture[1] = __HAL_TIM_GET_COMPARE(htim,TIM_CHANNEL_1);
	  count = 1;
	  is_capture_done = TRUE;
  }
  //incrementing pulse count
  pulse_count++;

  if(check_not_10sec){
  //10 seconds pulse count at 84mh clock is 210000000
  if( __HAL_TIM_GET_COMPARE(htim,TIM_CHANNEL_1) >= (210000000) ){
	  pulse_count_10_sec = pulse_count;
	  check_not_10sec = FALSE; //10 sec count completed

	  //printing 10 second pulse count
	  sprintf(ten_sec_data, "Number of pulses at 10 seconds is = %d\r\n",pulse_count_10_sec);
	  HAL_UART_Transmit(&Uart2,(uint8_t *)ten_sec_data,strlen(ten_sec_data),HAL_MAX_DELAY);

  }
  }

}


}

void Error_handler(void){
	while(1);
	// do something like turn on LEDs/
}


