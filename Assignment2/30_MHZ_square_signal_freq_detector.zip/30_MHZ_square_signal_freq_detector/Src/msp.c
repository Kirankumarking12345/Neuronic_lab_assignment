#include "main.h"

void HAL_MspInit(void)
{
 // to implement low level specs

	//1) Proority grouping of arm cortex mx processor

	HAL_NVIC_SetPriorityGrouping(NVIC_PRIORITYGROUP_4);

	//2. Enable the required required system exeption of the arm cortex mx processor
	SCB->SHCSR |= 0x7 << 16;

	//3. Configure the priority for the system exception
	 HAL_NVIC_SetPriority(MemoryManagement_IRQn,0,0);
	 HAL_NVIC_SetPriority(BusFault_IRQn,1,0);
	 HAL_NVIC_SetPriority(UsageFault_IRQn,2,0);
}

void HAL_UART_MspInit(UART_HandleTypeDef *huart)
{
	GPIO_InitTypeDef gpio_uart;
// here we do low level initialization of the USART2

	//1. Enable clock for usart2 peripheral and prt a enalble
	__HAL_RCC_USART2_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();
	//2. DO the [in muxng configurations

	//setting up uart tx pin
	gpio_uart.Pin = GPIO_PIN_2 ;
	gpio_uart.Mode = GPIO_MODE_AF_PP;
	gpio_uart.Pull = GPIO_PULLUP;
	gpio_uart.Speed = GPIO_SPEED_FREQ_LOW;
	gpio_uart.Alternate = GPIO_AF7_USART2 ;

	HAL_GPIO_Init(GPIOA, &gpio_uart);

	// setting up uart rx pin
	gpio_uart.Pin = GPIO_PIN_3 ; //uart2_rx
	HAL_GPIO_Init(GPIOA, &gpio_uart);

	//3. Enable the IRQ and setup the priority( NVIC settings)

	HAL_NVIC_EnableIRQ(USART2_IRQn);
	HAL_NVIC_SetPriority(USART2_IRQn, 15, 0);

}

void HAL_TIM_IC_MspInit(TIM_HandleTypeDef *htim)
{
	GPIO_InitTypeDef pin_A0;
	//enable the clock for timer2
	__HAL_RCC_TIM2_CLK_ENABLE();
	__HAL_RCC_GPIOA_CLK_ENABLE();

	//configure A0 pin as input channel for timer
	pin_A0.Pin = GPIO_PIN_0;
	pin_A0.Mode = GPIO_MODE_AF_PP;
	pin_A0.Alternate = GPIO_AF1_TIM2;
	HAL_GPIO_Init(GPIOA,&pin_A0);

	//nvic settings
	HAL_NVIC_SetPriority(TIM2_IRQn,15,0);
	HAL_NVIC_EnableIRQ(TIM2_IRQn);

}
