/*
 * main.h
 *
 *  Created on: 26-Jul-2022
 *      Author: kiran
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "stm32f4xx_hal.h"

#endif /* MAIN_H_ */
