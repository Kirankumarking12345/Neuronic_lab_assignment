/*
 * main.c
 *
 *  Created on: 26-Jul-2022
 *      Author: kiran
 */

#include <string.h>
#include "stm32f4xx_hal.h"
#include "main.h"
#define TRUE 1
#define FALSE 0


void SystemClock_Config(void);
void UART2_Init(void);
void Error_handler(void);
void GPIO_Init(void);
UART_HandleTypeDef huart2;

char *user_data = "The application is running.... \r\n";


uint8_t data_buffer[100];
uint8_t rcvd_data;
uint8_t count = 0;
uint8_t reception_complete = FALSE;

int main(void)
{
	HAL_Init();
	GPIO_Init();
	SystemClock_Config();
	UART2_Init();

	uint16_t len_data = strlen(user_data);
	HAL_UART_Transmit(&huart2,(uint8_t*)user_data,len_data,HAL_MAX_DELAY);

	while(1)
	{
		//take input from the serial
		while (reception_complete != TRUE)
			HAL_UART_Receive_IT(&huart2, &rcvd_data, 1);

		//compare the user input is high or low
		if (strcmp("HIGH", (char *) data_buffer) == 0)
		{
			//set GPIO pin 10 to HIGH
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_SET);

		}

		else if (strcmp("LOW", (char *) data_buffer) == 0)
		{
			//set GPIO pin 10 to LOW
			HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);

		}

		reception_complete = FALSE;
		count = 0;
		memset(data_buffer, 0, sizeof(data_buffer));
		rcvd_data = ' ';

	}


	return 0;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(rcvd_data == '\r')
	{
		reception_complete = TRUE;
	}
	else
	{
		data_buffer[count++] = rcvd_data;

	}


}

void GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();

  /*Set GPIO pin Output Level to 0 */
  HAL_GPIO_WritePin(GPIOA, GPIO_PIN_10, GPIO_PIN_RESET);

  /*Configuring GPIO pin : PA5 */
  GPIO_InitStruct.Pin = GPIO_PIN_10;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLUP;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

}
void SystemClock_Config(void)
{

}

void UART2_Init()
{
	huart2.Instance 		= USART2;
	huart2.Init.BaudRate 	= 115200;
	huart2.Init.WordLength	= UART_WORDLENGTH_8B;
	huart2.Init.StopBits	= UART_STOPBITS_1;
	huart2.Init.Parity		= UART_PARITY_NONE;
	huart2.Init.HwFlowCtl	= UART_HWCONTROL_NONE;
	huart2.Init.Mode		= UART_MODE_TX_RX;
	if(HAL_UART_Init(&huart2) != HAL_OK)
	{
		//There is a problem
		Error_handler();
	}
}
void Error_handler(void)
{
	while(1);

}
